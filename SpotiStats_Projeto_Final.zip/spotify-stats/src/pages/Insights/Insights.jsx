import { genreStats, listeningHours, moodData, overallStats } from "../../data/stats";
import StatBar from "../../components/StatBar/StatBar";
import MoodWheel from "../../components/MoodWheel/MoodWheel";
import styles from "./Insights.module.css";

const funFacts = [
  { emoji: "🔥", value: `${overallStats.streakDays} dias`, label: "Streak atual" },
  { emoji: "🌙", value: overallStats.favoriteTime, label: "Horário favorito" },
  { emoji: "🎵", value: overallStats.topGenre, label: "Gênero top" },
  { emoji: "⏱️", value: `${(overallStats.minutesThisMonth / 60).toFixed(0)}h`, label: "Este mês" },
];

const maxHour = Math.max(...listeningHours.map((h) => h.value));

export default function Insights() {
  return (
    <div className="page-wrapper">
      <div className="container">
        <h1 className="section-title">💡 Insights</h1>
        <p className="section-subtitle">
          Uma análise completa dos seus hábitos musicais
        </p>

        <div className={styles.insightsGrid}>

          {/* === Gêneros Favoritos === */}
          <div className={styles.panel}>
            <h2 className={styles.panelTitle}>🎼 Gêneros Favoritos</h2>
            {genreStats.map(({ name, percentage, color }) => (
              <StatBar
                key={name}
                label={name}
                percentage={percentage}
                color={color}
              />
            ))}
          </div>

          {/* === Fun Facts === */}
          <div className={styles.panel}>
            <h2 className={styles.panelTitle}>📊 Seus Números</h2>
            <div className={styles.factsGrid}>
              {funFacts.map(({ emoji, value, label }) => (
                <div key={label} className={styles.factCard}>
                  <div className={styles.factEmoji}>{emoji}</div>
                  <div className={styles.factValue}>{value}</div>
                  <div className={styles.factLabel}>{label}</div>
                </div>
              ))}
            </div>

            {/* Hora de pico de escuta */}
            <div style={{ marginTop: "24px" }}>
              <h3 style={{ fontSize: "0.9rem", fontWeight: 700, marginBottom: "12px", color: "var(--text-secondary)" }}>
                🕐 Horário de Escuta
              </h3>
              <div className={styles.hourGrid}>
                {listeningHours.map(({ hour, value }) => (
                  <div
                    key={hour}
                    className={styles.hourBar}
                    title={`${hour}: ${value} mins`}
                    style={{
                      height: `${(value / maxHour) * 100}%`,
                      background: value >= 70
                        ? "var(--spotify-green)"
                        : value >= 40
                        ? "rgba(29,185,84,0.5)"
                        : "rgba(29,185,84,0.2)",
                    }}
                  />
                ))}
              </div>
              <div className={styles.hourLabels}>
                {listeningHours.map(({ hour }) => (
                  <span key={hour} className={styles.hourLabel}>{hour}</span>
                ))}
              </div>
            </div>
          </div>

          {/* === MoodWheel — Componente Criativo === */}
          <div className={styles.moodPanel}>
            <h2 className={styles.panelTitle}>
              🎭 Análise de Humor Musical
              <span className="badge badge-green" style={{ marginLeft: "auto" }}>Componente Criativo</span>
            </h2>
            <p style={{ fontSize: "0.875rem", color: "var(--text-secondary)", marginBottom: "24px" }}>
              Baseado nas suas {overallStats.savedSongs} músicas salvas, identificamos como seus humores musicais se distribuem ao longo do tempo.
            </p>
            <MoodWheel moodData={moodData} />
          </div>

        </div>
      </div>
    </div>
  );
}
