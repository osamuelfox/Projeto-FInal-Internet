import { useNavigate } from "react-router-dom";
import { userProfile, overallStats } from "../../data/stats";
import { songs } from "../../data/songs";
import styles from "./Home.module.css";

const statCards = [
  { icon: "🎵", value: overallStats.hoursListened.toLocaleString(), label: "Horas Ouvidas" },
  { icon: "❤️", value: overallStats.savedSongs.toLocaleString(), label: "Músicas Salvas" },
  { icon: "🎤", value: overallStats.followedArtists, label: "Artistas Seguidos" },
  { icon: "📋", value: overallStats.playlistsCreated, label: "Playlists Criadas" },
];

const featuredSong = songs[0]; // Blinding Lights — top hit

export default function Home() {
  const navigate = useNavigate();

  return (
    <div className="page-wrapper">
      <div className="container">

        {/* ===== Profile Card ===== */}
        <section className={styles.hero}>
          <div className={styles.profileCard}>
            {/* Avatar */}
            <div className={styles.avatarWrapper}>
              <img
                src={userProfile.avatar}
                alt={userProfile.name}
                className={styles.avatar}
              />
              <div className={styles.onlineDot} title="Online" />
            </div>

            {/* Info */}
            <div className={styles.profileInfo}>
              <div style={{ display: "flex", alignItems: "center", gap: "10px", flexWrap: "wrap", marginBottom: "4px" }}>
                <h1 className={styles.profileName}>{userProfile.name}</h1>
                {userProfile.isPremium && (
                  <span className="badge badge-premium">✨ Premium</span>
                )}
              </div>
              <p className={styles.profileUsername}>{userProfile.username}</p>
              <div className={styles.profileMeta}>
                <span className={styles.metaItem}>
                  <strong>{userProfile.followers}</strong> seguidores
                </span>
                <span className={styles.metaItem}>
                  <strong>{userProfile.following}</strong> seguindo
                </span>
                <span className={styles.metaItem}>📍 {userProfile.country}</span>
                <span className={styles.metaItem}>
                  🗓️ Membro desde {userProfile.memberSince}
                </span>
              </div>
              <div style={{ marginTop: "12px" }}>
                <div className={styles.streakBadge}>
                  🔥 {overallStats.streakDays} dias de streak consecutivos
                </div>
              </div>
            </div>

            {/* CTA Button */}
            <button
              className={styles.ctaButton}
              onClick={() => navigate("/top-tracks")}
              id="btn-ver-top-tracks"
            >
              🎵 Ver Top Músicas
            </button>
          </div>

          {/* ===== Stats Grid ===== */}
          <div className={styles.statsGrid}>
            {statCards.map(({ icon, value, label }) => (
              <div key={label} className={styles.statCard}>
                <span className={styles.statIcon}>{icon}</span>
                <div className={styles.statValue}>{value}</div>
                <div className={styles.statLabel}>{label}</div>
              </div>
            ))}
          </div>

          {/* ===== Featured ===== */}
          <div className={styles.featuredSection}>
            <h2 className="section-title">🏆 Destaque do Mês</h2>
            <p className="section-subtitle">Sua música mais tocada esse mês</p>
            <div className={styles.featuredCard}>
              <img
                src={featuredSong.cover}
                alt={featuredSong.title}
                className={styles.featuredImage}
                onError={(e) => { e.target.src = "https://via.placeholder.com/160"; }}
              />
              <div className={styles.featuredInfo}>
                <span className={styles.featuredLabel}>🔥 Mais Tocada</span>
                <div className={styles.featuredTitle}>{featuredSong.title}</div>
                <div className={styles.featuredArtist}>{featuredSong.artist} · {featuredSong.album}</div>
                <div className={styles.featuredStats}>
                  <div className={styles.featuredStat}>
                    <span>{featuredSong.plays.lastMonth}</span> plays este mês
                  </div>
                  <div className={styles.featuredStat}>
                    <span>{featuredSong.plays.lastYear}</span> plays no ano
                  </div>
                  <div className={styles.featuredStat}>
                    ⏱️ <span>{featuredSong.duration}</span>
                  </div>
                </div>
                <div style={{ marginTop: "8px" }}>
                  <span className="badge badge-green">
                    🎵 Gênero predominante: {overallStats.topGenre}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Quick insight */}
          <div style={{ marginTop: "32px", background: "var(--bg-glass)", border: "1px solid var(--border-color)", borderRadius: "var(--radius-lg)", padding: "20px 24px", display: "flex", alignItems: "center", gap: "16px" }}>
            <span style={{ fontSize: "2rem" }}>🌙</span>
            <div>
              <div style={{ fontWeight: 700, marginBottom: "4px" }}>Você é um ouvinte noturno!</div>
              <div style={{ fontSize: "0.875rem", color: "var(--text-secondary)" }}>
                Seu horário de pico é entre <strong style={{ color: "var(--text-primary)" }}>{overallStats.favoriteTime}</strong> — você ouviu <strong style={{ color: "var(--spotify-green)" }}>{overallStats.minutesThisMonth.toLocaleString()} minutos</strong> de música este mês.
              </div>
            </div>
          </div>
        </section>

      </div>
    </div>
  );
}
