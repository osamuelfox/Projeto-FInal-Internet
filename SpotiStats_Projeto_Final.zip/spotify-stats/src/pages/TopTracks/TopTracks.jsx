import { useState } from "react";
import { songs, periodLabels } from "../../data/songs";
import SongCard from "../../components/SongCard/SongCard";
import styles from "./TopTracks.module.css";

// ============================================================
// LIFT STATE UP: O filtro de período é gerenciado AQUI (pai)
// e passado como props para o filho SongCard via `period`
// ============================================================

const periods = ["lastMonth", "sixMonths", "lastYear"];

const periodMessages = {
  lastMonth: {
    icon: "🗓️",
    text: (
      <>
        Exibindo suas músicas mais ouvidas no <strong>último mês</strong>. Você está em ritmo intenso!
      </>
    ),
  },
  sixMonths: {
    icon: "📅",
    text: (
      <>
        Um semestre de boas músicas! Veja o que dominou seus <strong>últimos 6 meses</strong>.
      </>
    ),
  },
  lastYear: {
    icon: "🏅",
    text: (
      <>
        O resumo completo do seu <strong>ano musical</strong>. Essas são as músicas que definiram 2024/2025!
      </>
    ),
  },
};

export default function TopTracks() {
  // Estado do filtro de período — Lift State Up
  const [period, setPeriod] = useState("lastMonth");

  // Ordenar músicas pelo período selecionado
  const sortedSongs = [...songs].sort((a, b) => b.plays[period] - a.plays[period]);
  const maxPlays = sortedSongs[0]?.plays[period] || 1;
  const msg = periodMessages[period];

  return (
    <div className="page-wrapper">
      <div className="container">
        <h1 className="section-title">🎵 Top Músicas</h1>
        <p className="section-subtitle">
          Suas {songs.length} faixas mais reproduzidas
        </p>

        {/* Filtro de Período — estado gerenciado no pai (Lift State Up) */}
        <div className={styles.filterBar} role="group" aria-label="Filtro de período">
          {periods.map((p) => (
            <button
              key={p}
              id={`filter-${p}`}
              className={`${styles.filterBtn} ${period === p ? styles.active : ""}`}
              onClick={() => setPeriod(p)}
            >
              {periodLabels[p]}
            </button>
          ))}
        </div>

        {/* Renderização condicional: mensagem muda conforme o período */}
        <div className={styles.periodMsg}>
          {msg.icon} {msg.text}
        </div>

        {/* Lista de músicas — componente SongCard reutilizado */}
        <div className={styles.list}>
          {sortedSongs.map((song, index) => (
            <SongCard
              key={song.id}
              song={song}
              rank={index + 1}
              maxPlays={maxPlays}
              period={period}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
