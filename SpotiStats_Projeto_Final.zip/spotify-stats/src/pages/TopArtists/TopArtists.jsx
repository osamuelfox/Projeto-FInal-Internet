import { useState } from "react";
import { artists } from "../../data/artists";
import ArtistCard from "../../components/ArtistCard/ArtistCard";
import styles from "./TopArtists.module.css";

// Coleta todos os gêneros únicos
const allGenres = ["Todos", ...new Set(artists.flatMap((a) => a.genres))];

export default function TopArtists() {
  const [activeGenre, setActiveGenre] = useState("Todos");

  // Renderização condicional: filtra artistas pelo gênero selecionado
  const filteredArtists =
    activeGenre === "Todos"
      ? artists
      : artists.filter((a) => a.genres.includes(activeGenre));

  const handleGenreClick = (genre) => {
    setActiveGenre((prev) => (prev === genre ? "Todos" : genre));
  };

  return (
    <div className="page-wrapper">
      <div className="container">
        <h1 className="section-title">🎤 Top Artistas</h1>
        <p className="section-subtitle">
          Os artistas que dominaram suas sessões de escuta
        </p>

        {/* Filtro por gênero */}
        <div className={styles.genreFilter} role="group" aria-label="Filtro por gênero">
          {allGenres.map((genre) => (
            <button
              key={genre}
              id={`genre-filter-${genre.replace(/[^a-z0-9]/gi, "-").toLowerCase()}`}
              className={`${styles.genreBtn} ${activeGenre === genre ? styles.active : ""}`}
              onClick={() => setActiveGenre(genre)}
            >
              {genre}
            </button>
          ))}
        </div>

        {/* Grid de artistas */}
        <div className={styles.grid}>
          {filteredArtists.length > 0 ? (
            filteredArtists.map((artist, index) => (
              <ArtistCard
                key={artist.id}
                artist={artist}
                rank={index + 1}
                activeGenre={activeGenre}
                onGenreClick={handleGenreClick}
              />
            ))
          ) : (
            <div className={styles.emptyState}>
              <span>🎭</span>
              <p>Nenhum artista encontrado para o gênero <strong>{activeGenre}</strong></p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
