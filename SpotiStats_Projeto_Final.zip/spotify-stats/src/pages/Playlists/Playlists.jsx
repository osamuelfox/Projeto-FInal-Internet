import { useState } from "react";
import { playlists } from "../../data/stats";
import { songs } from "../../data/songs";
import SongCard from "../../components/SongCard/SongCard";
import styles from "./Playlists.module.css";

const moodColors = {
  Energetic: { bg: "rgba(233,30,99,0.2)", color: "#E91E63" },
  Happy: { bg: "rgba(255,214,0,0.2)", color: "#FFD600" },
  Chill: { bg: "rgba(156,39,176,0.2)", color: "#9C27B0" },
  Melancholic: { bg: "rgba(33,150,243,0.2)", color: "#2196F3" },
  Focus: { bg: "rgba(29,185,84,0.2)", color: "#1DB954" },
};

export default function Playlists() {
  // Renderização condicional: qual playlist está expandida
  const [expandedId, setExpandedId] = useState(null);

  const handleToggle = (id) => {
    setExpandedId((prev) => (prev === id ? null : id));
  };

  return (
    <div className="page-wrapper">
      <div className="container">
        <h1 className="section-title">📋 Playlists</h1>
        <p className="section-subtitle">
          {playlists.length} playlists criadas — clique em uma para ver os detalhes
        </p>

        <div className={styles.grid}>
          {playlists.map((playlist) => {
            const isExpanded = expandedId === playlist.id;
            const mood = moodColors[playlist.mood] || moodColors.Focus;
            // Renderização condicional: busca músicas da playlist expandida
            const playlistSongs = isExpanded
              ? songs.filter((s) => playlist.songList.includes(s.id))
              : [];
            const maxPlays = playlistSongs.length > 0
              ? Math.max(...playlistSongs.map((s) => s.plays.lastMonth))
              : 1;

            return (
              <div
                key={playlist.id}
                id={`playlist-${playlist.id}`}
                className={`${styles.playlistCard} ${isExpanded ? styles.expanded : ""}`}
                onClick={() => handleToggle(playlist.id)}
              >
                {/* Cover */}
                <div className={styles.coverWrapper}>
                  <img
                    src={playlist.cover}
                    alt={playlist.name}
                    className={styles.cover}
                    onError={(e) => {
                      e.target.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(playlist.name)}&background=1DB954&color=fff&size=300`;
                    }}
                  />
                  <div className={styles.coverOverlay}>
                    <span
                      className={styles.moodBadge}
                      style={{ background: mood.bg, color: mood.color }}
                    >
                      {playlist.mood}
                    </span>
                  </div>
                </div>

                {/* Body */}
                <div className={styles.cardBody}>
                  <div className={styles.playlistName}>{playlist.name}</div>
                  <div className={styles.playlistMeta}>
                    <span>🎵 {playlist.songs} músicas</span>
                    <span>⏱️ {playlist.duration}</span>
                    <span>🕓 {playlist.lastUpdated}</span>
                  </div>
                  <p className={styles.playlistDesc}>{playlist.description}</p>
                  <div className={styles.expandIndicator}>
                    {isExpanded ? "▲ Fechar detalhes" : "▼ Ver detalhes"}
                  </div>
                </div>

                {/* Renderização condicional: detalhes expandidos */}
                {isExpanded && (
                  <div
                    className={styles.detailPanel}
                    onClick={(e) => e.stopPropagation()}
                  >
                    <div className={styles.detailTitle}>
                      🎵 Músicas em destaque
                    </div>
                    <div className={styles.songList}>
                      {playlistSongs.map((song, i) => (
                        <SongCard
                          key={song.id}
                          song={song}
                          rank={i + 1}
                          maxPlays={maxPlays}
                          period="lastMonth"
                        />
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
