import { useState } from "react";
import { songs } from "../../data/songs";
import SongCard from "../SongCard/SongCard";
import styles from "./MoodWheel.module.css";

// SVG pie chart slice generator
function polarToCartesian(cx, cy, r, angleDeg) {
  const rad = ((angleDeg - 90) * Math.PI) / 180;
  return {
    x: cx + r * Math.cos(rad),
    y: cy + r * Math.sin(rad),
  };
}

function describeSlice(cx, cy, r, innerR, startAngle, endAngle) {
  const start = polarToCartesian(cx, cy, r, startAngle);
  const end = polarToCartesian(cx, cy, r, endAngle);
  const innerStart = polarToCartesian(cx, cy, innerR, endAngle);
  const innerEnd = polarToCartesian(cx, cy, innerR, startAngle);
  const largeArc = endAngle - startAngle > 180 ? 1 : 0;

  return [
    `M ${start.x} ${start.y}`,
    `A ${r} ${r} 0 ${largeArc} 1 ${end.x} ${end.y}`,
    `L ${innerStart.x} ${innerStart.y}`,
    `A ${innerR} ${innerR} 0 ${largeArc} 0 ${innerEnd.x} ${innerEnd.y}`,
    "Z",
  ].join(" ");
}

export default function MoodWheel({ moodData }) {
  const [activeMood, setActiveMood] = useState(null);
  const [hoveredMood, setHoveredMood] = useState(null);

  const cx = 130, cy = 130, r = 120, innerR = 55;
  let currentAngle = 0;

  const slices = moodData.map((item) => {
    const angle = (item.percentage / 100) * 360;
    const slice = {
      ...item,
      startAngle: currentAngle,
      endAngle: currentAngle + angle,
      path: describeSlice(cx, cy, r, innerR, currentAngle, currentAngle + angle),
    };
    currentAngle += angle;
    return slice;
  });

  const displayMood = hoveredMood || activeMood;
  const displayData = displayMood ? moodData.find((m) => m.mood === displayMood) : null;

  const filteredSongs = activeMood
    ? songs.filter((s) => s.mood === activeMood)
    : [];

  const maxPlays = filteredSongs.length > 0
    ? Math.max(...filteredSongs.map((s) => s.plays.lastMonth))
    : 1;

  const handleSliceClick = (mood) => {
    setActiveMood((prev) => (prev === mood ? null : mood));
  };

  return (
    <div className={styles.container}>
      <p className={styles.title}>🎭 Roda de Humor Musical</p>
      <p style={{ fontSize: "0.8rem", color: "var(--text-muted)", textAlign: "center" }}>
        Clique em uma fatia para filtrar as músicas por humor
      </p>

      {/* SVG Wheel */}
      <div className={styles.svgWrapper}>
        <svg width="260" height="260" viewBox="0 0 260 260">
          <defs>
            <filter id="glow">
              <feGaussianBlur stdDeviation="3" result="coloredBlur" />
              <feMerge>
                <feMergeNode in="coloredBlur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>
          {slices.map((slice) => (
            <path
              key={slice.mood}
              d={slice.path}
              fill={slice.color}
              fillOpacity={activeMood && activeMood !== slice.mood ? 0.3 : 0.85}
              stroke="#0a0a0a"
              strokeWidth="2"
              className={`${styles.slice} ${activeMood === slice.mood ? styles.active : ""}`}
              onClick={() => handleSliceClick(slice.mood)}
              onMouseEnter={() => setHoveredMood(slice.mood)}
              onMouseLeave={() => setHoveredMood(null)}
              filter={activeMood === slice.mood ? "url(#glow)" : undefined}
            />
          ))}
          {/* Center circle */}
          <circle cx={cx} cy={cy} r={innerR - 4} fill="#0a0a0a" />
        </svg>

        {/* Center label */}
        <div className={styles.centerLabel}>
          <span className={styles.centerEmoji}>
            {displayData ? displayData.emoji : "🎵"}
          </span>
          <span className={styles.centerText}>
            {displayData ? `${displayData.percentage}%` : "humor"}
          </span>
        </div>
      </div>

      {/* Tooltip card */}
      {displayData && (
        <div className={styles.tooltip}>
          <div className={styles.tooltipMood} style={{ color: displayData.color }}>
            {displayData.emoji} {displayData.mood}
          </div>
          <div className={styles.tooltipDesc}>{displayData.description}</div>
          <div className={styles.tooltipPct} style={{ color: displayData.color }}>
            {displayData.percentage}%
          </div>
        </div>
      )}

      {/* Legend */}
      <div className={styles.legend}>
        {moodData.map((item) => (
          <div
            key={item.mood}
            className={`${styles.legendItem} ${activeMood === item.mood ? styles.active : ""}`}
            onClick={() => handleSliceClick(item.mood)}
          >
            <div className={styles.legendDot} style={{ background: item.color }} />
            {item.emoji} {item.mood}
          </div>
        ))}
      </div>

      {/* Filtered songs list */}
      {activeMood && filteredSongs.length > 0 && (
        <div className={styles.filteredSongs}>
          <p className={styles.filteredTitle}>
            Músicas com humor <strong style={{ color: moodData.find(m => m.mood === activeMood)?.color }}>{activeMood}</strong>
          </p>
          <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
            {filteredSongs.map((song, i) => (
              <SongCard
                key={song.id}
                song={song}
                rank={i + 1}
                maxPlays={maxPlays}
                period="lastMonth"
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
