import styles from "./ArtistCard.module.css";

const rankStyles = ["gold", "silver", "bronze", "default"];

export default function ArtistCard({ artist, rank, onGenreClick, activeGenre }) {
  const { name, image, genres, plays, topSong, bio, monthlyListeners } = artist;
  const rankStyle = rankStyles[rank - 1] || "default";
  const rankLabel = rank <= 3 ? ["🥇", "🥈", "🥉"][rank - 1] : `#${rank}`;

  return (
    <div className={styles.card}>
      {/* Image with overlay */}
      <div className={styles.imageWrapper}>
        <img
          src={image}
          alt={name}
          className={styles.image}
          onError={(e) => { e.target.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=1DB954&color=fff&size=300`; }}
        />
        <div className={styles.overlay}>
          <p className={styles.overlayBio}>{bio}</p>
        </div>
        <div className={`${styles.rankBadge} ${styles[rankStyle]}`}>
          {rankLabel}
        </div>
      </div>

      {/* Body */}
      <div className={styles.body}>
        <div className={styles.name}>{name}</div>
        <div className={styles.topSong}>🎵 {topSong}</div>

        {/* Genre tags */}
        <div className={styles.genres}>
          {genres.map((genre) => (
            <button
              key={genre}
              className={`${styles.genreTag} ${activeGenre === genre ? styles.active : ""}`}
              onClick={() => onGenreClick && onGenreClick(genre)}
            >
              {genre}
            </button>
          ))}
        </div>

        {/* Stats */}
        <div className={styles.stats}>
          <div>
            <div className={styles.playsCount}>{plays.toLocaleString()}</div>
            <div className={styles.playsLabel}>plays</div>
          </div>
          <div className={styles.listeners}>
            {monthlyListeners}<br />ouvintes/mês
          </div>
        </div>
      </div>
    </div>
  );
}
