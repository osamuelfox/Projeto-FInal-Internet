import styles from "./StatBar.module.css";

export default function StatBar({ label, percentage, color = "#1DB954", showValue = true }) {
  return (
    <div className={styles.wrapper}>
      <div className={styles.header}>
        <span className={styles.label}>{label}</span>
        {showValue && <span className={styles.value}>{percentage}%</span>}
      </div>
      <div className={styles.track}>
        <div
          className={styles.fill}
          style={{
            width: `${percentage}%`,
            background: `linear-gradient(90deg, ${color}, ${color}cc)`,
          }}
        />
      </div>
    </div>
  );
}
