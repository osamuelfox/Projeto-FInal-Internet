import styles from "./SongCard.module.css";

const moodColors = {
  Energetic: { bg: "rgba(233,30,99,0.15)", color: "#E91E63" },
  Happy: { bg: "rgba(255,214,0,0.15)", color: "#FFD600" },
  Chill: { bg: "rgba(156,39,176,0.15)", color: "#9C27B0" },
  Melancholic: { bg: "rgba(33,150,243,0.15)", color: "#2196F3" },
  Focus: { bg: "rgba(29,185,84,0.15)", color: "#1DB954" },
};

export default function SongCard({ song, rank, maxPlays, period = "lastMonth" }) {
  const { title, artist, cover, duration, plays, mood } = song;
  const currentPlays = plays[period];
  const percentage = maxPlays > 0 ? (currentPlays / maxPlays) * 100 : 0;
  const moodStyle = moodColors[mood] || moodColors.Focus;
  const isTop = rank <= 3;

  return (
    <div className={styles.card}>
      <div style={{ display: "flex", alignItems: "center", gap: "14px", padding: "14px 16px" }}>
        {/* Rank */}
        <span className={`${styles.rank} ${isTop ? styles.top : ""}`}>
          {rank <= 3 ? ["🥇", "🥈", "🥉"][rank - 1] : `#${rank}`}
        </span>

        {/* Cover */}
        <img src={cover} alt={`${title} cover`} className={styles.cover} onError={(e) => { e.target.src = "https://via.placeholder.com/48"; }} />

        {/* Info */}
        <div className={styles.info}>
          <div className={styles.title}>{title}</div>
          <div className={styles.artist}>{artist}</div>
          <div style={{ display: "flex", alignItems: "center", gap: "8px", marginTop: "4px" }}>
            <span
              className={styles.moodTag}
              style={{ background: moodStyle.bg, color: moodStyle.color }}
            >
              {mood}
            </span>
            <span className={styles.plays}>{currentPlays} plays</span>
          </div>
          <div className={styles.playBar}>
            <div
              className={styles.playBarFill}
              style={{ width: `${percentage}%` }}
            />
          </div>
        </div>

        {/* Duration */}
        <span className={styles.duration}>{duration}</span>
      </div>
    </div>
  );
}
